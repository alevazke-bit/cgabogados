<?php
   class Redux_Customizer_Control_link_color extends Redux_Customizer_Control {
     public $type = "redux-link_color";
   }