<?php
   class Redux_Customizer_Control_spacing extends Redux_Customizer_Control {
     public $type = "redux-spacing";
   }