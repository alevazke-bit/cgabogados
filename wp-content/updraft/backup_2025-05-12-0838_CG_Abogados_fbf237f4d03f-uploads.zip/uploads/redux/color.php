<?php
   class Redux_Customizer_Control_color extends Redux_Customizer_Control {
     public $type = "redux-color";
   }