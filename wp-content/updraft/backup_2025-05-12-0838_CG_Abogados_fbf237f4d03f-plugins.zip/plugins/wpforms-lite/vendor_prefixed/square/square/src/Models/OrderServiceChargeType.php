<?php

declare (strict_types=1);
namespace WPForms\Vendor\Square\Models;

class OrderServiceChargeType
{
    public const AUTO_GRATUITY = 'AUTO_GRATUITY';
    public const CUSTOM = 'CUSTOM';
}
