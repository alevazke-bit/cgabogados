<?php

declare (strict_types=1);
namespace WPForms\Vendor\Square\Models;

class TenderBuyNowPayLaterDetailsBrand
{
    public const OTHER_BRAND = 'OTHER_BRAND';
    public const AFTERPAY = 'AFTERPAY';
}
